var t = 3; 
var u = 7; 

var v = u-t;
console.log("Result " + v); 
