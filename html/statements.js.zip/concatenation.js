var firstName = 'Manuel';
var lastName = 'Torres';

console.log(firstName + lastName);